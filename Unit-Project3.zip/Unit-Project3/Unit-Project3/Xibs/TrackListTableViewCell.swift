import UIKit
import Nuke

class TrackListTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var trackImage: UIImageView!
    @IBOutlet weak var artistName: UILabel!
    @IBOutlet weak var trackName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        trackImage.layer.cornerRadius = 8
    }
    
    var currentMovie: MovieObj? {
        didSet {
            if let currentMovie = currentMovie {
                configureCell(movie: currentMovie)
            }
        }
    }
    
    private func configureCell(movie: MovieObj) {
        artistName.text = movie.overview
        trackName.text = movie.title
        var url = "https://image.tmdb.org/t/p/original/"
        url.append(movie.backdropPath)
        Nuke.loadImage(with: URL(string: url)!, into: trackImage, completion: nil)
    }
}
