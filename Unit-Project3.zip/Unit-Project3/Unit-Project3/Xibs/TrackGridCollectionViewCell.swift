import UIKit
import Nuke

class TrackGridCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var trackImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        trackImage.layer.cornerRadius = 8
    }
    
    var currentMovie: MovieObj? {
        didSet {
            if let currentMovie = currentMovie {
                configureCell(movie: currentMovie)
            }
        }
    }
    
    private func configureCell(movie: MovieObj) {
        
        var url = "https://image.tmdb.org/t/p/original/"
        url.append(movie.backdropPath)

        Nuke.loadImage(with: URL(string:url)!, into: trackImage, completion: nil)
    }
    
}
