import UIKit
//Contact For more solutions:- +92 308 7265877

class TabController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
