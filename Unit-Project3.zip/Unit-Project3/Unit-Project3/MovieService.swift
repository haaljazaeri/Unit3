import Foundation

protocol AppDataSerializerProtocol {
    func parseData<T: Codable>(data: Data, ofType: T.Type, completion: @escaping (Result<T, Error>) -> Void)
}

class AppDataSerializer: AppDataSerializerProtocol {
    func parseData<T: Codable>(data: Data, ofType: T.Type, completion: @escaping (Result<T, Error>) -> Void) {
        do{
            let result = try JSONDecoder().decode(ofType.self, from: data)
            completion(.success(result))
        }
        catch {
            completion(.failure(error))
        }
    }
}

//MARK: API Data
class MovieService: AppDataSerializer {
    
    private override init() {}
    
    static let sharedInstance = MovieService()
    
    func getTrackList(completion: @escaping (Result<Movie, Error>) -> Void) {
        
        let url = "https://api.themoviedb.org/3/movie/now_playing?api_key=69cee415d581694dd84f85314eac5a28"
        
        NetworkService.sharedInstance.getDataFromApi(urlString: url) { result in
            switch result {
            case .success(let data):
                self.parseData(data: data, ofType: Movie.self) { result in
                    switch result {
                    case .success(let trackResult):
                        completion(.success(trackResult))
                    case.failure(let error):
                        print(error.localizedDescription)
                    }
                }
            case .failure(let error):
                switch error {
                case .dataError:
                    print("Data Error")
                case .badUrl:
                    print("BadUrl Error")
                case .serverError:
                    print("Server Error")
                }
            }
        }
    }
}
