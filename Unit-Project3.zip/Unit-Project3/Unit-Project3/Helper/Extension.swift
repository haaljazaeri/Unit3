import Foundation
import UIKit

extension UITableView {
    
    public func register(_ cell: UITableViewCell.Type) {
        let nib = UINib(nibName: cell.identifier, bundle: nil)
        register(nib, forCellReuseIdentifier: cell.identifier)
    }
}


public extension UITableViewCell {
    
    static var identifier: String {
        return String(describing: self)
    }
}


extension UICollectionView {
    
    public func register(_ cell: UICollectionViewCell.Type) {
        let nib = UINib(nibName: cell.identifier, bundle: nil)
        register(nib, forCellWithReuseIdentifier: cell.identifier)
    }
}


public extension UICollectionViewCell {
    
    static var identifier: String {
        return String(describing: self)
    }
    
}
