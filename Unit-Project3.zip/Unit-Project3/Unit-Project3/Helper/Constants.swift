import Foundation

struct KTrack {
    
    struct ArtistName {
        
        static let artist1 = "Leonardo da Vinci"
        static let artist2 = "Michelangelo"
        static let artist3 = "Rembrandti"
        static let artist4 = "Claude Monet"
        static let artist5 = "Claude Monet"
        
    }
    
    struct TrackName {
        
        static let track1 = "I Do It for You"
        static let track2 = "The 59th Street Bridge Song (Feelin' Groovy)"
        static let track3 = "Achy Breaky Heart"
        static let track4 = "Act Naturally"
        static let track5 = "Addicted to Love"
        
    }
    
    struct CollectionName {
        
        static let collection = "The Album"
    }
    
    struct PrimaryGenre {
        
        static let genre = "K-Pop"
    }
    
    struct TrackTime {
        
        static let timeInMilliSeconds = 15705
    }
    
    struct ArtworkUrl {
        
        static let url1 = "https://images.unsplash.com/photo-1511379938547-c1f69419868d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80"
        static let url2 = "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80"
        static let url3 = "https://images.unsplash.com/photo-1619983081563-430f63602796?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80"
        static let url4 = "https://images.unsplash.com/photo-1507838153414-b4b713384a76?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80"
        static let url5 = "https://plus.unsplash.com/premium_photo-1681396936891-ed738c53cb21?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2788&q=80"
        
    }
    
}
