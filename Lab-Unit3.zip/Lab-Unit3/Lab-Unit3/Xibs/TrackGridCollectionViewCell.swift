import UIKit
import Nuke

class TrackGridCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var trackImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        trackImage.layer.cornerRadius = 8
    }
    
    var currentTrack: TrackObj? {
        didSet {
            if let currentTrack = currentTrack {
                configureCell(track: currentTrack)
            }
        }
    }
    
    private func configureCell(track: TrackObj) {
        Nuke.loadImage(with: URL(string: track.artworkUrl100)!, into: trackImage, completion: nil)
    }
    
}
