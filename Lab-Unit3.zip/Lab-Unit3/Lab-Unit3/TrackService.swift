import Foundation

protocol AppDataSerializerProtocol {
    func parseData<T: Codable>(data: Data, ofType: T.Type, completion: @escaping (Result<T, Error>) -> Void)
}

class AppDataSerializer: AppDataSerializerProtocol {
    func parseData<T: Codable>(data: Data, ofType: T.Type, completion: @escaping (Result<T, Error>) -> Void) {
        do{
            let result = try JSONDecoder().decode(ofType.self, from: data)
            completion(.success(result))
        }
        catch {
            completion(.failure(error))
        }
    }
}

//MARK: API Data
class TrackService: AppDataSerializer {
    
    private override init() {}
    
    static let sharedInstance = TrackService()
    
    func getTrackList(completion: @escaping (Result<Track, Error>) -> Void) {
        
        let url = "https://itunes.apple.com/search?term=blackpink&attribute=artistTerm"
        
        NetworkService.sharedInstance.getDataFromApi(urlString: url) { result in
            switch result {
            case .success(let data):
                self.parseData(data: data, ofType: Track.self) { result in
                    switch result {
                    case .success(let trackResult):
                        completion(.success(trackResult))
                    case.failure(let error):
                        print(error.localizedDescription)
                    }
                }
            case .failure(let error):
                switch error {
                case .dataError:
                    print("Data Error")
                case .badUrl:
                    print("BadUrl Error")
                case .serverError:
                    print("Server Error")
                }
            }
        }
    }
}
