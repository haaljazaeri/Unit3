import Foundation

struct Track: Codable {
    
    let resultCount: Int
    let results: [TrackObj]
    
}

// MARK: - Result
struct TrackObj: Codable {
    let wrapperType: WrapperType
    let kind: Kind
    let artistID: Int
    let collectionID: Int?
    let trackID: Int
    let artistName: ArtistName
    let collectionName: String?
    let trackName: String
    let collectionCensoredName: String?
    let trackCensoredName: String
    let collectionArtistName: String?
    let artistViewURL: String
    let collectionViewURL: String?
    let trackViewURL: String
    let previewURL: String
    let artworkUrl30, artworkUrl60, artworkUrl100: String
    let collectionPrice, trackPrice: Double?
    let collectionExplicitness, trackExplicitness: Explicitness
    let discCount, discNumber, trackCount, trackNumber: Int?
    let trackTimeMillis: Int
    let country: Country
    let currency: Currency
    let primaryGenreName: PrimaryGenreName
    let isStreamable: Bool?
    let collectionArtistID: Int?
    let contentAdvisoryRating: String?
    
    enum CodingKeys: String, CodingKey {
        case wrapperType, kind
        case artistID = "artistId"
        case collectionID = "collectionId"
        case trackID = "trackId"
        case artistName, collectionName, trackName, collectionCensoredName, trackCensoredName, collectionArtistName
        case artistViewURL = "artistViewUrl"
        case collectionViewURL = "collectionViewUrl"
        case trackViewURL = "trackViewUrl"
        case previewURL = "previewUrl"
        case artworkUrl30, artworkUrl60, artworkUrl100, collectionPrice, trackPrice, collectionExplicitness, trackExplicitness, discCount, discNumber, trackCount, trackNumber, trackTimeMillis, country, currency, primaryGenreName, isStreamable
        case collectionArtistID = "collectionArtistId"
        case contentAdvisoryRating
    }
}

enum ArtistName: String, Codable {
    case blackpink = "BLACKPINK"
    case blackpinkSelenaGomez = "BLACKPINK & Selena Gomez"
    case duaLipaBLACKPINK = "Dua Lipa & BLACKPINK"
    case jennieFromBLACKPINK = "JENNIE (from BLACKPINK)"
    case ladyGagaBLACKPINK = "Lady Gaga & BLACKPINK"
    case ladyGagaBLACKPINKShygirlMuraMasa = "Lady Gaga, BLACKPINK, Shygirl & Mura Masa"
}

enum Explicitness: String, Codable {
    case cleaned = "cleaned"
    case explicit = "explicit"
    case notExplicit = "notExplicit"
}

enum Country: String, Codable {
    case usa = "USA"
}

enum Currency: String, Codable {
    case usd = "USD"
}

enum Kind: String, Codable {
    case musicVideo = "music-video"
    case song = "song"
}

enum PrimaryGenreName: String, Codable {
    case kPop = "K-Pop"
    case pop = "Pop"
}

enum WrapperType: String, Codable {
    case track = "track"
}
