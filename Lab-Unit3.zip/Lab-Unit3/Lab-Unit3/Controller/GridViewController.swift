import UIKit

class GridViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var trackCollection: UICollectionView!
    
    var trackList = [TrackObj]() {
        didSet {
            if trackList.count > 0 {
                DispatchQueue.main.async { [weak self] in
                    self?.trackCollection.reloadData()
                }
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        trackCollection.register(TrackGridCollectionViewCell.self)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        TrackService.sharedInstance.getTrackList { result in
            
            switch (result) {
                
            case .success(let data):
                self.trackList = data.results
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return trackList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let gridCell = trackCollection.dequeueReusableCell(withReuseIdentifier: TrackGridCollectionViewCell.identifier, for: indexPath) as? TrackGridCollectionViewCell {
            gridCell.currentTrack = trackList[indexPath.row]
            return gridCell
        }
        return UICollectionViewCell()
    }
}

extension GridViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let numberOfCol = 3
        let leftInsect = 10
        let rightInsect = 10
        let SectionInsect = leftInsect + rightInsect // Padding from Boundary
        let interCellSpacing = 10 // Horizontally
        let lineCellSpacing = 10 // Vertically
        
        let horizontalCalSpaces = ( interCellSpacing * (numberOfCol - 1))
        let actualWidth = (CGFloat((collectionView.frame.width - CGFloat(SectionInsect))) - CGFloat(horizontalCalSpaces)) / CGFloat(numberOfCol)
        
        return CGSize(width: actualWidth, height: actualWidth )
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
}
