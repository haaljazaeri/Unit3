import UIKit

class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var trackTableView: UITableView!
    
    var trackList = [TrackObj]() {
        didSet {
            if trackList.count > 0 {
                DispatchQueue.main.async { [weak self] in
                    self?.trackTableView.reloadData()
                }
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        trackTableView.register(TrackListTableViewCell.self)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        TrackService.sharedInstance.getTrackList { result in
            
            switch (result) {
                
            case .success(let data):
                self.trackList = data.results
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return trackList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let trackCell = trackTableView.dequeueReusableCell(withIdentifier: TrackListTableViewCell.identifier, for: indexPath) as? TrackListTableViewCell {
            trackCell.currentTrack = trackList[indexPath.row]
            return trackCell
        }
        return UITableViewCell()
    }
}
