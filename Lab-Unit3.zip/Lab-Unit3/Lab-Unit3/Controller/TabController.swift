import UIKit

class TabController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
